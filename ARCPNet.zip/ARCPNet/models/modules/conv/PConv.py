############## Partial_conv3    start  by  AI&CV  AI little monsters #######################################################
import torch
import torch.nn as nn


class Partial_conv3(nn.Module):

    def __init__(self, c1, n_div=4):
        super().__init__()
        self.dim_conv3 = c1 // n_div
        self.dim_untouched = c1 - self.dim_conv3
        self.partial_conv3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)

    def forward(self, x):
        # for training/inference
        x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
        x1 = self.partial_conv3(x1)
        x = torch.cat((x1, x2), 1)

        return x

############## Partial_conv3    end  by  AI&CV  AI little monsters #######################################################