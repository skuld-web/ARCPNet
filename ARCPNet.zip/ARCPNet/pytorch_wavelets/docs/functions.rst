API Guide
=========

Decimated WT
------------

.. automodule:: pytorch_wavelets
    :members: DWTForward, DWTInverse
    :show-inheritance:

Dual Tree Complex WT
--------------------

.. automodule:: pytorch_wavelets
    :members: DTCWTForward, DTCWTInverse
    :show-inheritance:

